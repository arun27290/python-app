"""
ITIS Incident Management Analyzer
==================================
Run:  python app.py
Open: http://localhost:5050
"""

import os, io, json, warnings
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from flask import Flask, request, render_template_string, jsonify, send_file

warnings.filterwarnings("ignore")

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024   # 50 MB upload limit

# ─────────────────────────────────────────────────────────────────────────────
# COLUMN ALIASES  – maps common alternative names → canonical names used here
# ─────────────────────────────────────────────────────────────────────────────
ALIASES = {
    # Incident ID
    "Incident_Number":  "Incident_Number",
    "IncidentNumber":   "Incident_Number",
    "Incident_Nember":  "Incident_Number",    # typo variant seen in your data
    "IncidentID":       "Incident_Number",
    "Incident ID":      "Incident_Number",

    # Dates
    "ReportedDate":     "ReportedDate",
    "Reported Date":    "ReportedDate",
    "LastResolvedDate": "LastResolvedDate",
    "Last Resolved Date":"LastResolvedDate",
    "ResolvedDate":     "LastResolvedDate",
    "SubmitDate":       "SubmitDate",
    "Submit Date":      "SubmitDate",

    # Text fields
    "Summary":                      "Summary",
    "Service_Type":                 "Service_Type",
    "ServiceType":                  "Service_Type",
    "HPD_CI":                       "HPD_CI",
    "HPDCI":                        "HPD_CI",
    "CI":                           "HPD_CI",
    "SLAStatus":                    "SLAStatus",
    "SLA_Status":                   "SLAStatus",
    "SLA Status":                   "SLAStatus",
    "Priority":                     "Priority",
    "AssignedGroup":                "AssignedGroup",
    "Assigned Group":               "AssignedGroup",
    "Assignee":                     "Assignee",
    "Assigned_Support_Organisation":"Assigned_Support_Organisation",
    "AssignedSupportOrganisation":  "Assigned_Support_Organisation",
    "Organisation":                 "Assigned_Support_Organisation",
    "Organization":                 "Assigned_Support_Organisation",
    "Assigned_Support_Company":     "Assigned_Support_Company",
    "Company":                      "Assigned_Support_Company",
    "Status":                       "Status",
    "Group_Transfers":              "Group_Transfers",
    "GroupTransfers":               "Group_Transfers",
    "Group Transfers":              "Group_Transfers",
}

# Excel serial date base (Windows: Jan 1 1900 = 1)
EXCEL_EPOCH = datetime(1899, 12, 30)

def excel_serial_to_dt(val):
    """Convert Excel serial number to datetime."""
    try:
        f = float(val)
        if f > 0:
            return EXCEL_EPOCH + timedelta(days=f)
    except (TypeError, ValueError):
        pass
    return pd.NaT

def parse_date_col(series):
    """
    Smart date parser: handles Excel serials (numbers), datetime strings,
    pandas Timestamps, and already-parsed datetime objects.
    """
    # Already datetime
    if pd.api.types.is_datetime64_any_dtype(series):
        return series
    # Try direct numeric → Excel serial
    if pd.api.types.is_numeric_dtype(series):
        return series.apply(excel_serial_to_dt)
    # Try string/object parse
    parsed = pd.to_datetime(series, errors="coerce", dayfirst=False)
    # If majority failed, try Excel serial on object col
    if parsed.isna().mean() > 0.5:
        parsed = series.apply(lambda v: excel_serial_to_dt(v) if pd.notna(v) else pd.NaT)
    return parsed

def normalise_columns(df):
    """Rename columns using ALIASES; strip whitespace from headers."""
    df.columns = [c.strip() for c in df.columns]
    rename_map = {}
    for col in df.columns:
        if col in ALIASES:
            rename_map[col] = ALIASES[col]
    df = df.rename(columns=rename_map)
    return df

def priority_sort_key(p):
    order = {"P1 - Critical": 0, "Critical": 0,
             "P2 - High": 1, "High": 1,
             "P3 - Medium": 2, "Medium": 2,
             "P4 - Low": 3, "Low": 3}
    return order.get(p, 99)

# ─────────────────────────────────────────────────────────────────────────────
# ANALYSIS ENGINE
# ─────────────────────────────────────────────────────────────────────────────
def analyse(df_raw):
    df = normalise_columns(df_raw.copy())

    # ── Parse date columns ────────────────────────────────────────────────────
    for col in ["ReportedDate", "LastResolvedDate", "SubmitDate"]:
        if col in df.columns:
            df[col] = parse_date_col(df[col])

    # ── Derived fields ────────────────────────────────────────────────────────
    has_reported  = "ReportedDate"     in df.columns
    has_resolved  = "LastResolvedDate" in df.columns
    has_submitted = "SubmitDate"       in df.columns

    if has_reported:
        df["_reported_valid"] = df["ReportedDate"].notna()
        df["Month"]  = df["ReportedDate"].dt.to_period("M").astype(str)
        df["Week"]   = df["ReportedDate"].dt.to_period("W").astype(str)
        df["DayOfWeek"] = df["ReportedDate"].dt.day_name()

    if has_reported and has_resolved:
        df["ResolutionHours"] = (
            (df["LastResolvedDate"] - df["ReportedDate"])
            .dt.total_seconds() / 3600
        ).round(2)
        # Sanity: drop negatives (data errors)
        df.loc[df["ResolutionHours"] < 0, "ResolutionHours"] = np.nan

    # ── Resolved subset ───────────────────────────────────────────────────────
    has_status = "Status" in df.columns
    if has_status:
        resolved = df[df["Status"].str.strip().str.lower().isin(
            ["resolved", "closed", "completed"]
        )].copy()
    elif has_resolved:
        resolved = df[df["LastResolvedDate"].notna()].copy()
    else:
        resolved = df.copy()

    total = len(df)

    # ── Date range ────────────────────────────────────────────────────────────
    if has_reported and df["ReportedDate"].notna().any():
        date_min = df["ReportedDate"].min().strftime("%d-%b-%Y")
        date_max = df["ReportedDate"].max().strftime("%d-%b-%Y")
    else:
        date_min = date_max = "N/A"

    # ── KPIs ──────────────────────────────────────────────────────────────────
    open_statuses = ["open", "in progress", "pending", "assigned", "work in progress", "wip"]
    if has_status:
        open_ct   = int(df[df["Status"].str.strip().str.lower().isin(open_statuses)].shape[0])
        closed_ct = int(df[df["Status"].str.strip().str.lower().isin(["resolved","closed","completed"])].shape[0])
    else:
        open_ct   = 0
        closed_ct = total

    # SLA
    has_sla = "SLAStatus" in df.columns
    if has_sla:
        sla_met_ct = int(df[df["SLAStatus"].str.strip().str.lower().isin(
            ["met","within sla","sla met","ok","yes"]
        )].shape[0])
        sla_pct = round(sla_met_ct / total * 100, 1) if total else 0
    else:
        sla_met_ct = sla_pct = 0

    # MTTR
    if "ResolutionHours" in df.columns and df["ResolutionHours"].notna().any():
        mttr = round(float(df["ResolutionHours"].mean()), 2)
        total_hours = round(float(df["ResolutionHours"].sum()), 1)
    else:
        mttr = total_hours = 0

    # P1 count
    has_priority = "Priority" in df.columns
    if has_priority:
        p1_ct = int(df[df["Priority"].str.lower().str.contains("critical|p1", na=False)].shape[0])
    else:
        p1_ct = 0

    # Avg group transfers
    has_xfer = "Group_Transfers" in df.columns
    avg_xfer = round(float(pd.to_numeric(df["Group_Transfers"], errors="coerce").mean()), 1) if has_xfer else 0

    # ── Monthly volume ────────────────────────────────────────────────────────
    if has_reported and "Month" in df.columns:
        vol = df.groupby("Month").size().reset_index(name="count").sort_values("Month")
        vol_labels = vol["Month"].tolist()
        vol_data   = vol["count"].tolist()
    else:
        vol_labels = vol_data = []

    # ── Priority breakdown ────────────────────────────────────────────────────
    if has_priority:
        pri = df["Priority"].value_counts().reset_index()
        pri.columns = ["Priority", "count"]
        pri["sort"] = pri["Priority"].apply(priority_sort_key)
        pri = pri.sort_values("sort").drop("sort", axis=1)
        pri_labels = pri["Priority"].tolist()
        pri_data   = pri["count"].tolist()
    else:
        pri_labels = pri_data = []

    # ── Status breakdown ──────────────────────────────────────────────────────
    if has_status:
        sta = df["Status"].value_counts().reset_index()
        sta.columns = ["Status", "count"]
        sta_labels = sta["Status"].tolist()
        sta_data   = sta["count"].tolist()
    else:
        sta_labels = sta_data = []

    # ── SLA breakdown ─────────────────────────────────────────────────────────
    if has_sla:
        sla_s = df["SLAStatus"].value_counts().reset_index()
        sla_s.columns = ["SLAStatus", "count"]
        sla_labels = sla_s["SLAStatus"].tolist()
        sla_data   = sla_s["count"].tolist()
    else:
        sla_labels = sla_data = []

    # ── SLA % by priority ─────────────────────────────────────────────────────
    if has_priority and has_sla:
        def sla_pct_fn(x):
            met = x["SLAStatus"].str.strip().str.lower().isin(
                ["met","within sla","sla met","ok","yes"])
            return round(met.sum() / len(x) * 100, 1) if len(x) else 0
        sla_by_pri = df.groupby("Priority").apply(sla_pct_fn).reset_index(name="pct")
        sla_by_pri["sort"] = sla_by_pri["Priority"].apply(priority_sort_key)
        sla_by_pri = sla_by_pri.sort_values("sort").drop("sort", axis=1)
        sla_pri_labels = sla_by_pri["Priority"].tolist()
        sla_pri_vals   = sla_by_pri["pct"].tolist()
    else:
        sla_pri_labels = sla_pri_vals = []

    # ── SLA trend monthly ─────────────────────────────────────────────────────
    if has_sla and has_reported and "Month" in df.columns:
        def sla_monthly(x):
            met = x["SLAStatus"].str.strip().str.lower().isin(
                ["met","within sla","sla met","ok","yes"])
            return round(met.sum() / len(x) * 100, 1) if len(x) else 0
        sla_tr = df.groupby("Month").apply(sla_monthly).reset_index(name="pct").sort_values("Month")
        sla_tr_labels = sla_tr["Month"].tolist()
        sla_tr_vals   = sla_tr["pct"].tolist()
    else:
        sla_tr_labels = sla_tr_vals = []

    # ── Incidents by AssignedGroup ────────────────────────────────────────────
    has_group = "AssignedGroup" in df.columns
    if has_group:
        grp = df.groupby("AssignedGroup").size().reset_index(name="count")
        grp = grp.sort_values("count", ascending=False)
        grp_labels = grp["AssignedGroup"].tolist()
        grp_data   = grp["count"].tolist()
    else:
        grp_labels = grp_data = []

    # ── MTTR by group ─────────────────────────────────────────────────────────
    if has_group and "ResolutionHours" in df.columns:
        mttr_grp = df.groupby("AssignedGroup")["ResolutionHours"].mean().round(1).reset_index()
        mttr_grp.columns = ["group", "mttr"]
        mttr_grp = mttr_grp.sort_values("mttr")
        mttr_grp_labels = mttr_grp["group"].tolist()
        mttr_grp_vals   = mttr_grp["mttr"].tolist()
    else:
        mttr_grp_labels = mttr_grp_vals = []

    # ── Assignee table ────────────────────────────────────────────────────────
    has_assignee = "Assignee" in df.columns
    has_org      = "Assigned_Support_Organisation" in df.columns
    group_by_cols = [c for c in ["Assignee","AssignedGroup","Assigned_Support_Organisation"] if c in df.columns]
    if group_by_cols:
        at_agg = {"_cnt": ("Incident_Number" if "Incident_Number" in df.columns else df.columns[0], "count")}
        if has_status:
            at_agg["_res"] = ("Status", lambda x: x.str.strip().str.lower().isin(["resolved","closed","completed"]).sum())
        if "ResolutionHours" in df.columns:
            at_agg["_mttr"] = ("ResolutionHours", lambda x: round(x.mean(), 1))
        if has_sla:
            at_agg["_sla"] = ("SLAStatus", lambda x: round(
                x.str.strip().str.lower().isin(["met","within sla","sla met","ok","yes"]).sum() / len(x) * 100, 1
            ))
        if has_xfer:
            at_agg["_xfer"] = ("Group_Transfers", lambda x: round(pd.to_numeric(x, errors="coerce").mean(), 1))

        at_df = df.groupby(group_by_cols).agg(**{k: v for k, v in at_agg.items()}).reset_index()
        at_df = at_df.rename(columns={"_cnt":"Total","_res":"Resolved","_mttr":"MTTR_hrs","_sla":"SLA_Pct","_xfer":"Avg_Transfers"})
        at_df = at_df.sort_values("Total", ascending=False)
        assignee_rows = at_df.fillna("—").to_dict("records")
    else:
        assignee_rows = []

    # ── HPD_CI breakdown ──────────────────────────────────────────────────────
    has_ci = "HPD_CI" in df.columns
    if has_ci:
        ci_all = df.groupby("HPD_CI").size().reset_index(name="count").sort_values("count", ascending=False)
        ci_top = ci_all.head(15)
        ci_labels = ci_top["HPD_CI"].tolist()
        ci_data   = ci_top["count"].tolist()
        # CI with count > 3
        ci_gt3 = ci_all[ci_all["count"] > 3].copy()
        ci_gt3_rows = ci_gt3.to_dict("records")
    else:
        ci_labels = ci_data = []
        ci_gt3_rows = []

    # ── Service type ──────────────────────────────────────────────────────────
    has_svc = "Service_Type" in df.columns
    if has_svc:
        svc = df["Service_Type"].value_counts().reset_index()
        svc.columns = ["type","count"]
        svc_labels = svc["type"].tolist()
        svc_data   = svc["count"].tolist()
    else:
        svc_labels = svc_data = []

    # ── Group transfers distribution ──────────────────────────────────────────
    if has_xfer:
        xf = pd.to_numeric(df["Group_Transfers"], errors="coerce")
        xf_counts = xf.value_counts().sort_index().reset_index()
        xf_counts.columns = ["transfers","count"]
        xf_labels = [str(int(v)) for v in xf_counts["transfers"].tolist()]
        xf_data   = xf_counts["count"].tolist()
    else:
        xf_labels = xf_data = []

    # ── Day of week ───────────────────────────────────────────────────────────
    if has_reported and "DayOfWeek" in df.columns:
        day_order = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
        dow = df["DayOfWeek"].value_counts().reindex(day_order, fill_value=0)
        dow_labels = dow.index.tolist()
        dow_data   = dow.values.tolist()
    else:
        dow_labels = dow_data = []

    # ── Org summary ───────────────────────────────────────────────────────────
    if has_org:
        org_grp = df.groupby("Assigned_Support_Organisation")
        org_agg = org_grp.size().reset_index(name="total")
        if has_status:
            org_open = org_grp["Status"].apply(
                lambda x: x.str.strip().str.lower().isin(open_statuses).sum()
            ).reset_index(name="open")
            org_agg = org_agg.merge(org_open, on="Assigned_Support_Organisation")
        if has_sla:
            org_sla_pct = org_grp["SLAStatus"].apply(
                lambda x: round(x.str.strip().str.lower().isin(
                    ["met","within sla","sla met","ok","yes"]).sum() / len(x) * 100, 1)
            ).reset_index(name="sla_pct")
            org_agg = org_agg.merge(org_sla_pct, on="Assigned_Support_Organisation")
        if "ResolutionHours" in df.columns:
            org_mttr = org_grp["ResolutionHours"].mean().round(1).reset_index(name="mttr")
            org_agg = org_agg.merge(org_mttr, on="Assigned_Support_Organisation")
        org_rows = org_agg.fillna("—").to_dict("records")
    else:
        org_rows = []

    # ── Detected columns for info panel ───────────────────────────────────────
    detected_cols = list(df.columns)

    return {
        # meta
        "total": total, "open_ct": open_ct, "closed_ct": closed_ct,
        "date_min": date_min, "date_max": date_max,
        "sla_met_ct": sla_met_ct, "sla_pct": sla_pct,
        "mttr": mttr, "total_hours": total_hours,
        "p1_ct": p1_ct, "avg_xfer": avg_xfer,
        "detected_cols": detected_cols,

        # charts
        "vol_labels": vol_labels, "vol_data": vol_data,
        "pri_labels": pri_labels, "pri_data": pri_data,
        "sta_labels": sta_labels, "sta_data": sta_data,
        "sla_labels": sla_labels, "sla_data": sla_data,
        "sla_pri_labels": sla_pri_labels, "sla_pri_vals": sla_pri_vals,
        "sla_tr_labels": sla_tr_labels, "sla_tr_vals": sla_tr_vals,
        "grp_labels": grp_labels, "grp_data": grp_data,
        "mttr_grp_labels": mttr_grp_labels, "mttr_grp_vals": mttr_grp_vals,
        "ci_labels": ci_labels, "ci_data": ci_data,
        "ci_gt3_rows": ci_gt3_rows,
        "svc_labels": svc_labels, "svc_data": svc_data,
        "xf_labels": xf_labels, "xf_data": xf_data,
        "dow_labels": dow_labels, "dow_data": dow_data,

        # tables
        "assignee_rows": assignee_rows,
        "org_rows": org_rows,
    }


# ─────────────────────────────────────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template_string(UPLOAD_PAGE)

@app.route("/upload", methods=["POST"])
def upload():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    f = request.files["file"]
    if f.filename == "":
        return jsonify({"error": "No file selected"}), 400

    fname = f.filename.lower()
    try:
        if fname.endswith(".xlsx") or fname.endswith(".xls"):
            df = pd.read_excel(io.BytesIO(f.read()), engine="openpyxl" if fname.endswith(".xlsx") else "xlrd")
        elif fname.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(f.read()))
        else:
            return jsonify({"error": "Unsupported file type. Use .xlsx, .xls, or .csv"}), 400
    except Exception as e:
        return jsonify({"error": f"Could not read file: {str(e)}"}), 400

    if df.empty:
        return jsonify({"error": "File is empty or could not be parsed"}), 400

    try:
        result = analyse(df)
    except Exception as e:
        return jsonify({"error": f"Analysis error: {str(e)}"}), 500

    return jsonify(result)


# ─────────────────────────────────────────────────────────────────────────────
# UPLOAD PAGE  (HTML served from Python string)
# ─────────────────────────────────────────────────────────────────────────────
UPLOAD_PAGE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>ITIS Incident Analyzer</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet"/>
<style>
:root{
  --bg:#07090f; --surf:#0e1118; --card:#131720; --card2:#171d2a;
  --border:#1f2738; --border2:#263047;
  --blue:#4a8cff; --red:#ff4f6a; --green:#30d988; --yellow:#ffc240;
  --purple:#a78bfa; --cyan:#22d3ee; --orange:#fb923c;
  --text:#edf2ff; --muted:#7b8db0; --dim:#3a4b6b;
  --grad: linear-gradient(135deg,#1a2540,#0d1425);
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{background:var(--bg);color:var(--text);font-family:'Syne',sans-serif;min-height:100vh;overflow-x:hidden}

/* ── NOISE TEXTURE OVERLAY ── */
body::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:0;opacity:.5}

/* ── HEADER ── */
.hdr{position:sticky;top:0;z-index:500;background:rgba(7,9,15,.92);backdrop-filter:blur(14px);
     border-bottom:1px solid var(--border);padding:14px 32px;
     display:flex;align-items:center;justify-content:space-between}
.brand{display:flex;align-items:center;gap:12px}
.brand-icon{width:36px;height:36px;border-radius:8px;
  background:linear-gradient(135deg,var(--blue),var(--purple));
  display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0}
.brand-name{font-size:1rem;font-weight:800;letter-spacing:-.02em}
.brand-name span{color:var(--blue)}
.hdr-pills{display:flex;gap:8px}
.pill{background:var(--card);border:1px solid var(--border);padding:4px 12px;
      border-radius:20px;font-family:'DM Mono',monospace;font-size:.68rem;color:var(--muted)}
.pill.live{border-color:var(--green);color:var(--green)}
.dot{width:6px;height:6px;border-radius:50%;background:var(--green);
     box-shadow:0 0 6px var(--green);display:inline-block;margin-right:5px;animation:blink 2s infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.2}}

/* ── UPLOAD ZONE ── */
#upload-section{position:relative;z-index:1;display:flex;flex-direction:column;align-items:center;
  justify-content:center;min-height:calc(100vh - 65px);padding:40px 20px;
  background:radial-gradient(ellipse 80% 60% at 50% 30%,rgba(74,140,255,.07) 0%,transparent 70%)}
.upload-card{width:100%;max-width:620px;background:var(--card);border:1px solid var(--border);
  border-radius:20px;padding:48px 40px;text-align:center;position:relative;overflow:hidden}
.upload-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;
  background:linear-gradient(90deg,var(--blue),var(--purple),var(--cyan))}
.upload-title{font-size:1.7rem;font-weight:800;margin-bottom:8px;letter-spacing:-.03em}
.upload-title span{color:var(--blue)}
.upload-sub{color:var(--muted);font-size:.88rem;margin-bottom:32px;line-height:1.6}
.drop-zone{border:2px dashed var(--border2);border-radius:14px;padding:40px 24px;
  cursor:pointer;transition:all .25s;position:relative;background:var(--card2)}
.drop-zone:hover,.drop-zone.drag{border-color:var(--blue);background:rgba(74,140,255,.06)}
.drop-zone input{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%}
.drop-icon{font-size:2.5rem;margin-bottom:12px}
.drop-text{font-size:.9rem;color:var(--muted);line-height:1.6}
.drop-text strong{color:var(--text)}
.drop-formats{margin-top:10px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap}
.fmt-badge{background:var(--surf);border:1px solid var(--border);padding:3px 10px;
  border-radius:6px;font-size:.68rem;font-family:'DM Mono',monospace;color:var(--muted)}
.upload-btn{margin-top:24px;background:linear-gradient(135deg,var(--blue),var(--purple));
  border:none;color:#fff;padding:14px 40px;border-radius:12px;font-size:.95rem;
  font-weight:700;cursor:pointer;font-family:'Syne',sans-serif;letter-spacing:-.01em;
  transition:opacity .2s,transform .15s;width:100%}
.upload-btn:hover{opacity:.9;transform:translateY(-1px)}
.upload-btn:disabled{opacity:.5;cursor:not-allowed;transform:none}
.file-name{margin-top:12px;font-size:.8rem;color:var(--green);font-family:'DM Mono',monospace}

/* ── PROGRESS ── */
#progress-overlay{display:none;position:fixed;inset:0;background:rgba(7,9,15,.85);
  z-index:900;align-items:center;justify-content:center;flex-direction:column;gap:16px}
#progress-overlay.show{display:flex}
.spinner{width:48px;height:48px;border:3px solid var(--border2);border-top-color:var(--blue);
  border-radius:50%;animation:spin 0.8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.progress-text{color:var(--muted);font-size:.88rem}

/* ── DASHBOARD ── */
#dashboard{display:none;position:relative;z-index:1}
#dashboard.show{display:block}

/* TABS */
.tabs-bar{background:var(--surf);border-bottom:1px solid var(--border);
  padding:0 28px;display:flex;gap:2px;overflow-x:auto;position:sticky;top:65px;z-index:400}
.tab{padding:13px 18px;cursor:pointer;font-size:.82rem;font-weight:600;
  color:var(--muted);border-bottom:2px solid transparent;transition:all .2s;
  white-space:nowrap;user-select:none;letter-spacing:-.01em}
.tab:hover{color:var(--text)}
.tab.on{color:var(--blue);border-bottom-color:var(--blue)}

/* PAGE */
.page{display:none;padding:24px 28px}
.page.on{display:block}

/* KPI GRID */
.kpi-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}
.kpi{background:var(--card);border:1px solid var(--border);border-radius:13px;
  padding:18px 16px;position:relative;overflow:hidden;transition:transform .15s,border-color .2s;cursor:default}
.kpi:hover{transform:translateY(-2px)}
.kpi-accent{position:absolute;top:0;left:0;right:0;height:2px}
.kpi-lbl{font-size:.63rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:8px}
.kpi-val{font-size:1.8rem;font-weight:800;font-family:'DM Mono',monospace;line-height:1;letter-spacing:-.03em}
.kpi-sub{font-size:.63rem;color:var(--dim);margin-top:5px}
.kpi-icon{position:absolute;right:14px;top:14px;font-size:1.3rem;opacity:.25}

/* SECTION LABEL */
.sec{font-size:.65rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  color:var(--dim);margin:22px 0 12px;display:flex;align-items:center;gap:10px}
.sec::after{content:'';flex:1;height:1px;background:var(--border)}

/* CHART CARD */
.cc{background:var(--card);border:1px solid var(--border);border-radius:13px;padding:20px}
.cc-hd{display:flex;align-items:center;gap:8px;margin-bottom:16px}
.cc-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.cc-title{font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}
.cc-badge{margin-left:auto;background:var(--surf);border:1px solid var(--border);
  padding:2px 8px;border-radius:8px;font-size:.63rem;color:var(--dim);font-family:'DM Mono',monospace}

/* GRIDS */
.g2{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px}
.g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-bottom:16px}
.g4{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:16px;margin-bottom:16px}
.g3-2{display:grid;grid-template-columns:3fr 2fr;gap:16px;margin-bottom:16px}
.full{margin-bottom:16px}

/* TABLE */
.tbl-wrap{overflow-x:auto;border-radius:10px}
table{width:100%;border-collapse:collapse;font-size:.78rem}
thead th{padding:9px 12px;background:var(--surf);color:var(--muted);font-weight:700;
  font-size:.65rem;text-transform:uppercase;letter-spacing:.07em;text-align:left;
  border-bottom:1px solid var(--border);white-space:nowrap;position:sticky;top:0}
tbody td{padding:10px 12px;border-bottom:1px solid rgba(31,39,56,.7);vertical-align:middle}
tbody tr:hover td{background:rgba(74,140,255,.05)}
tbody tr:last-child td{border-bottom:none}

/* CHIPS */
.chip{display:inline-block;padding:2px 9px;border-radius:8px;font-size:.68rem;font-weight:700;white-space:nowrap}
.c-met    {background:rgba(48,217,136,.15);color:var(--green)}
.c-breach {background:rgba(255,79,106,.15); color:var(--red)}
.c-pend   {background:rgba(255,194,64,.15); color:var(--yellow)}
.c-blue   {background:rgba(74,140,255,.12); color:var(--blue)}
.c-purple {background:rgba(167,139,250,.12);color:var(--purple)}
.c-orange {background:rgba(251,146,60,.12); color:var(--orange)}

/* MINI BAR */
.mbar{display:flex;align-items:center;gap:7px;min-width:100px}
.mbar-bg{flex:1;height:5px;background:var(--border);border-radius:3px;overflow:hidden}
.mbar-fill{height:100%;border-radius:3px;transition:width .5s}

/* INFO PANEL */
.info-panel{background:var(--card);border:1px solid var(--border);border-radius:13px;
  padding:18px 20px;margin-bottom:16px}
.info-cols{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}
.info-col{background:var(--surf);border:1px solid var(--border);padding:3px 10px;
  border-radius:6px;font-size:.68rem;font-family:'DM Mono',monospace;color:var(--muted)}

/* NEW ANALYSIS BTN */
.new-btn{margin:0 28px 20px;background:var(--card);border:1px solid var(--border);
  color:var(--muted);padding:10px 20px;border-radius:10px;cursor:pointer;
  font-family:'Syne',sans-serif;font-size:.82rem;font-weight:600;transition:all .2s}
.new-btn:hover{border-color:var(--blue);color:var(--blue)}

/* ALERT */
.alert{background:rgba(255,79,106,.1);border:1px solid rgba(255,79,106,.3);
  border-radius:10px;padding:14px 16px;color:var(--red);font-size:.85rem;margin-top:12px}

footer{text-align:center;padding:24px;color:var(--dim);font-size:.7rem;
  border-top:1px solid var(--border);margin-top:4px}

@media(max-width:1100px){.kpi-grid{grid-template-columns:repeat(2,1fr)}.g4{grid-template-columns:1fr 1fr}}
@media(max-width:800px){.g2,.g3,.g3-2{grid-template-columns:1fr}.kpi-grid{grid-template-columns:1fr 1fr}}
@media(max-width:500px){.kpi-grid{grid-template-columns:1fr}.page{padding:14px 12px}.tabs-bar{padding:0 12px}}
</style>
</head>
<body>

<!-- HEADER -->
<header class="hdr">
  <div class="brand">
    <div class="brand-icon">⚡</div>
    <div class="brand-name">ITIS <span>Incident</span> Analyzer</div>
  </div>
  <div class="hdr-pills">
    <span class="pill live"><span class="dot"></span>Live</span>
    <span class="pill" id="file-pill">No file loaded</span>
  </div>
</header>

<!-- PROGRESS OVERLAY -->
<div id="progress-overlay">
  <div class="spinner"></div>
  <div class="progress-text">Analysing your incident data…</div>
</div>

<!-- UPLOAD SECTION -->
<section id="upload-section">
  <div class="upload-card">
    <div class="upload-title">ITIS <span>Incident</span> Dashboard</div>
    <div class="upload-sub">Upload your Excel or CSV export from ITIS.<br>Columns are auto-detected — extra columns are preserved and shown.</div>
    <div class="drop-zone" id="drop-zone">
      <input type="file" id="file-input" accept=".xlsx,.xls,.csv"/>
      <div class="drop-icon">📂</div>
      <div class="drop-text"><strong>Click to browse</strong> or drag &amp; drop your file here</div>
      <div class="drop-formats">
        <span class="fmt-badge">.xlsx</span>
        <span class="fmt-badge">.xls</span>
        <span class="fmt-badge">.csv</span>
      </div>
    </div>
    <div class="file-name" id="chosen-file"></div>
    <div id="upload-error"></div>
    <button class="upload-btn" id="analyse-btn" disabled onclick="doAnalyse()">Analyse File →</button>
  </div>
</section>

<!-- DASHBOARD -->
<div id="dashboard">
  <button class="new-btn" onclick="resetApp()">← Upload New File</button>

  <!-- Tabs -->
  <nav class="tabs-bar">
    <div class="tab on"  onclick="goTab('overview',this)">📊 Overview</div>
    <div class="tab"     onclick="goTab('trends',this)">📈 Trends</div>
    <div class="tab"     onclick="goTab('sla',this)">🎯 SLA Analysis</div>
    <div class="tab"     onclick="goTab('team',this)">👥 Team Performance</div>
    <div class="tab"     onclick="goTab('ci',this)">🖥 CI &amp; Service</div>
    <div class="tab"     onclick="goTab('data',this)">🔍 Data Info</div>
  </nav>

  <!-- ── OVERVIEW ── -->
  <section class="page on" id="pg-overview">
    <div class="kpi-grid" id="kpi-grid"></div>
    <div class="g4" id="mini-charts-row"></div>
    <div class="g2">
      <div class="cc"><div class="cc-hd"><span class="cc-dot" style="background:var(--blue)"></span><span class="cc-title">Priority Distribution</span></div><canvas id="c-pri" height="220"></canvas></div>
      <div class="cc"><div class="cc-hd"><span class="cc-dot" style="background:var(--green)"></span><span class="cc-title">Status Breakdown</span></div><canvas id="c-sta" height="220"></canvas></div>
    </div>
    <div class="full cc">
      <div class="cc-hd"><span class="cc-dot" style="background:var(--orange)"></span><span class="cc-title">Incidents Resolved by AssignedGroup</span><span class="cc-badge" id="grp-badge"></span></div>
      <canvas id="c-grp" height="100"></canvas>
    </div>
    <div class="full cc">
      <div class="cc-hd"><span class="cc-dot" style="background:var(--cyan)"></span><span class="cc-title">Organisation Summary</span></div>
      <div class="tbl-wrap"><table><thead><tr><th>Organisation</th><th>Total</th><th>Open</th><th>SLA Met %</th><th>MTTR (hrs)</th><th>SLA Bar</th></tr></thead><tbody id="org-tbody"></tbody></table></div>
    </div>
  </section>

  <!-- ── TRENDS ── -->
  <section class="page" id="pg-trends">
    <div class="full cc">
      <div class="cc-hd"><span class="cc-dot" style="background:var(--blue)"></span><span class="cc-title">Monthly Incident Volume</span></div>
      <canvas id="c-vol" height="110"></canvas>
    </div>
    <div class="g2">
      <div class="cc"><div class="cc-hd"><span class="cc-dot" style="background:var(--yellow)"></span><span class="cc-title">Incidents by Day of Week</span></div><canvas id="c-dow" height="220"></canvas></div>
      <div class="cc"><div class="cc-hd"><span class="cc-dot" style="background:var(--purple)"></span><span class="cc-title">Group Transfers Distribution</span></div><canvas id="c-xfer" height="220"></canvas></div>
    </div>
    <div class="full cc">
      <div class="cc-hd"><span class="cc-dot" style="background:var(--green)"></span><span class="cc-title">SLA Compliance Trend — Monthly %</span></div>
      <canvas id="c-sla-trend" height="110"></canvas>
    </div>
  </section>

  <!-- ── SLA ── -->
  <section class="page" id="pg-sla">
    <div class="g2">
      <div class="cc"><div class="cc-hd"><span class="cc-dot" style="background:var(--green)"></span><span class="cc-title">SLAStatus Breakdown</span></div><canvas id="c-sla-donut" height="220"></canvas></div>
      <div class="cc"><div class="cc-hd"><span class="cc-dot" style="background:var(--yellow)"></span><span class="cc-title">SLA Compliance % by Priority</span></div><canvas id="c-sla-pri" height="220"></canvas></div>
    </div>
    <div class="full cc">
      <div class="cc-hd"><span class="cc-dot" style="background:var(--blue)"></span><span class="cc-title">MTTR by AssignedGroup (hours) — lower is better</span></div>
      <canvas id="c-mttr-grp" height="110"></canvas>
    </div>
  </section>

  <!-- ── TEAM ── -->
  <section class="page" id="pg-team">
    <div class="full cc">
      <div class="cc-hd"><span class="cc-dot" style="background:var(--cyan)"></span><span class="cc-title">Assignee / Team Performance Table</span></div>
      <div class="tbl-wrap"><table>
        <thead><tr id="team-thead"></tr></thead>
        <tbody id="team-tbody"></tbody>
      </table></div>
    </div>
  </section>

  <!-- ── CI & SERVICE ── -->
  <section class="page" id="pg-ci">
    <div class="g2">
      <div class="cc"><div class="cc-hd"><span class="cc-dot" style="background:var(--cyan)"></span><span class="cc-title">Top HPD_CI by Incident Count</span></div><canvas id="c-ci" height="280"></canvas></div>
      <div class="cc"><div class="cc-hd"><span class="cc-dot" style="background:var(--orange)"></span><span class="cc-title">Service Type Breakdown</span></div><canvas id="c-svc" height="280"></canvas></div>
    </div>
    <div class="full cc">
      <div class="cc-hd"><span class="cc-dot" style="background:var(--red)"></span>
        <span class="cc-title">HPD_CI with Incident Count &gt; 3 (Repeat Offenders)</span>
        <span class="cc-badge" id="ci3-badge"></span>
      </div>
      <div class="tbl-wrap"><table>
        <thead><tr><th>#</th><th>HPD_CI (Asset / Server)</th><th>Incident Count</th><th>Volume</th></tr></thead>
        <tbody id="ci3-tbody"></tbody>
      </table></div>
    </div>
  </section>

  <!-- ── DATA INFO ── -->
  <section class="page" id="pg-data">
    <div class="info-panel">
      <div class="sec" style="margin:0 0 8px">Detected Columns</div>
      <div class="info-cols" id="col-list"></div>
    </div>
    <div class="g2">
      <div class="cc">
        <div class="cc-hd"><span class="cc-dot" style="background:var(--blue)"></span><span class="cc-title">Column → Mapped Field</span></div>
        <div id="col-map-info" style="font-size:.78rem;color:var(--muted);line-height:1.9;font-family:'DM Mono',monospace"></div>
      </div>
      <div class="cc">
        <div class="cc-hd"><span class="cc-dot" style="background:var(--green)"></span><span class="cc-title">Date Column Note</span></div>
        <div style="font-size:.82rem;color:var(--muted);line-height:1.8">
          Your date columns are stored as <strong style="color:var(--yellow)">Excel serial numbers</strong>.<br><br>
          The app automatically converts them:<br>
          <span style="color:var(--blue);font-family:'DM Mono',monospace">serial × 86400 → epoch → datetime</span><br><br>
          ReportedDate and LastResolvedDate are used to calculate:<br>
          • <strong style="color:var(--green)">MTTR</strong> (Mean Time To Resolve)<br>
          • Total hours invested in resolving incidents<br>
          • Monthly volume trends
        </div>
      </div>
    </div>
  </section>

  <footer id="dash-footer"></footer>
</div>

<script>
// ── globals ───────────────────────────────────────────────────────────────────
let charts = {};
let D = null;
let selectedFile = null;

Chart.defaults.color = '#7b8db0';
Chart.defaults.borderColor = '#1f2738';
Chart.defaults.font.family = "'Syne',sans-serif";
Chart.defaults.font.size = 11;

const PALETTE = ['#4a8cff','#ff4f6a','#30d988','#ffc240','#a78bfa','#22d3ee','#fb923c','#ec4899','#34d399','#f87171'];
const PRI_MAP = {'P1 - Critical':'#ff4f6a','Critical':'#ff4f6a','P2 - High':'#ffc240','High':'#ffc240','P3 - Medium':'#4a8cff','Medium':'#4a8cff','P4 - Low':'#30d988','Low':'#30d988'};
const SLA_MAP = {'Met':'#30d988','Breached':'#ff4f6a','Pending':'#ffc240','Exempt':'#7b8db0','Within SLA':'#30d988','SLA Met':'#30d988','OK':'#30d988','Yes':'#30d988'};

// ── upload handling ───────────────────────────────────────────────────────────
const fileInput = document.getElementById('file-input');
const chosenFile = document.getElementById('chosen-file');
const analyseBtn = document.getElementById('analyse-btn');
const dropZone   = document.getElementById('drop-zone');

fileInput.addEventListener('change', () => {
  selectedFile = fileInput.files[0];
  if (selectedFile) {
    chosenFile.textContent = '📄 ' + selectedFile.name + ' (' + (selectedFile.size/1024).toFixed(1) + ' KB)';
    analyseBtn.disabled = false;
    document.getElementById('upload-error').innerHTML = '';
  }
});

dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('drag'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag'));
dropZone.addEventListener('drop', e => {
  e.preventDefault(); dropZone.classList.remove('drag');
  if (e.dataTransfer.files.length) {
    selectedFile = e.dataTransfer.files[0];
    chosenFile.textContent = '📄 ' + selectedFile.name;
    analyseBtn.disabled = false;
  }
});

function doAnalyse() {
  if (!selectedFile) return;
  const fd = new FormData();
  fd.append('file', selectedFile);
  document.getElementById('progress-overlay').classList.add('show');
  analyseBtn.disabled = true;
  document.getElementById('upload-error').innerHTML = '';

  fetch('/upload', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
      document.getElementById('progress-overlay').classList.remove('show');
      if (data.error) {
        document.getElementById('upload-error').innerHTML =
          '<div class="alert">⚠ ' + data.error + '</div>';
        analyseBtn.disabled = false;
        return;
      }
      D = data;
      buildDashboard(data);
    })
    .catch(err => {
      document.getElementById('progress-overlay').classList.remove('show');
      document.getElementById('upload-error').innerHTML =
        '<div class="alert">⚠ Network error: ' + err.message + '</div>';
      analyseBtn.disabled = false;
    });
}

function resetApp() {
  // Destroy all charts
  Object.values(charts).forEach(c => { try { c.destroy(); } catch(_){} });
  charts = {};
  D = null;
  document.getElementById('dashboard').classList.remove('show');
  document.getElementById('upload-section').style.display = '';
  analyseBtn.disabled = false;
  fileInput.value = '';
  chosenFile.textContent = '';
  document.getElementById('file-pill').textContent = 'No file loaded';
  // reset tabs
  document.querySelectorAll('.tab').forEach((t,i) => { t.classList.toggle('on', i===0); });
  document.querySelectorAll('.page').forEach((p,i) => { p.classList.toggle('on', i===0); });
}

function goTab(name, el) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('on'));
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('on'));
  document.getElementById('pg-' + name).classList.add('on');
  el.classList.add('on');
}

// ── chart helper ─────────────────────────────────────────────────────────────
function mkChart(id, type, labels, datasets, extra={}) {
  if (charts[id]) { charts[id].destroy(); }
  const ctx = document.getElementById(id);
  if (!ctx) return;
  charts[id] = new Chart(ctx, {
    type,
    data: { labels, datasets },
    options: {
      responsive: true, maintainAspectRatio: true,
      plugins: { legend: { labels: { color: '#7b8db0', boxWidth: 11, padding: 14 } } },
      ...extra
    }
  });
  return charts[id];
}

// ── build dashboard ───────────────────────────────────────────────────────────
function buildDashboard(d) {
  document.getElementById('file-pill').textContent = selectedFile ? selectedFile.name : 'File loaded';
  document.getElementById('upload-section').style.display = 'none';
  document.getElementById('dashboard').classList.add('show');
  document.getElementById('dash-footer').textContent =
    'ITIS Incident Analyzer · Columns: ' + d.detected_cols.join(' · ') + ' · Powered by Python + Flask';

  buildKPIs(d);
  buildCharts(d);
  buildTables(d);
  buildDataInfo(d);
}

// ── KPIs ──────────────────────────────────────────────────────────────────────
function buildKPIs(d) {
  const grid = document.getElementById('kpi-grid');
  const kpis = [
    { label:'Total Incidents',   val: d.total,         color:'var(--blue)',   icon:'📋', sub:'All records in file' },
    { label:'Open / Active',     val: d.open_ct,       color:'var(--red)',    icon:'🔴', sub:'Open · Pending · Assigned' },
    { label:'Closed',            val: d.closed_ct,     color:'var(--green)',  icon:'✅', sub:'Resolved & Closed' },
    { label:'SLA Compliance',    val: d.sla_pct+'%',   color:'var(--green)',  icon:'🎯', sub:d.sla_met_ct+' incidents met SLA' },
    { label:'MTTR',              val: d.mttr+'h',      color:'var(--yellow)', icon:'⏱', sub:'Mean Time to Resolve' },
    { label:'Total Hours',       val: d.total_hours+'h',color:'var(--orange)',icon:'⏰', sub:'Total resolution time invested' },
    { label:'P1 Critical',       val: d.p1_ct,         color:'var(--red)',    icon:'🚨', sub:'Highest priority incidents' },
    { label:'Avg Transfers',     val: d.avg_xfer,      color:'var(--cyan)',   icon:'🔄', sub:'Avg group transfers per incident' },
  ];
  grid.innerHTML = kpis.map(k => `
    <div class="kpi">
      <div class="kpi-accent" style="background:${k.color}"></div>
      <div class="kpi-icon">${k.icon}</div>
      <div class="kpi-lbl">${k.label}</div>
      <div class="kpi-val" style="color:${k.color}">${k.val}</div>
      <div class="kpi-sub">${k.sub}</div>
    </div>`).join('');

  // Date range
  const extra = document.createElement('div');
  extra.style.cssText = 'grid-column:1/-1;background:var(--card);border:1px solid var(--border);border-radius:13px;padding:12px 18px;display:flex;align-items:center;gap:16px;font-size:.8rem;';
  extra.innerHTML = `<span style="color:var(--muted)">📅 <strong style="color:var(--text)">Date Range:</strong></span>
    <span style="color:var(--blue);font-family:'DM Mono',monospace">${d.date_min}</span>
    <span style="color:var(--dim)">→</span>
    <span style="color:var(--blue);font-family:'DM Mono',monospace">${d.date_max}</span>`;
  grid.appendChild(extra);
}

// ── charts ────────────────────────────────────────────────────────────────────
function buildCharts(d) {
  const scaleOpts = { y:{grid:{color:'#1f2738'}}, x:{grid:{display:false}} };
  const scaleOptsYpct = { y:{grid:{color:'#1f2738'},ticks:{callback:v=>v+'%'}}, x:{grid:{display:false}} };

  // Priority doughnut
  if (d.pri_labels.length) mkChart('c-pri','doughnut',d.pri_labels,[{
    data:d.pri_data, backgroundColor:d.pri_labels.map(l=>PRI_MAP[l]||PALETTE[4]),
    borderWidth:2, borderColor:'#131720'
  }],{cutout:'62%'});

  // Status doughnut
  if (d.sta_labels.length) mkChart('c-sta','doughnut',d.sta_labels,[{
    data:d.sta_data, backgroundColor:PALETTE, borderWidth:2, borderColor:'#131720'
  }],{cutout:'58%'});

  // Group bar
  if (d.grp_labels.length) {
    document.getElementById('grp-badge').textContent = d.grp_labels.length+' groups';
    mkChart('c-grp','bar',d.grp_labels,[{
      label:'Incidents', data:d.grp_data,
      backgroundColor:'rgba(74,140,255,.75)', borderRadius:6, borderSkipped:false
    }],{indexAxis:'y',plugins:{legend:{display:false}},scales:{x:{grid:{color:'#1f2738'}},y:{grid:{display:false}}}});
  }

  // Volume line
  if (d.vol_labels.length) mkChart('c-vol','line',d.vol_labels,[{
    label:'Incidents', data:d.vol_data,
    borderColor:'#4a8cff', backgroundColor:'rgba(74,140,255,.1)',
    fill:true, tension:.4, pointRadius:5,
    pointBackgroundColor:'#4a8cff', pointBorderColor:'#07090f', pointBorderWidth:2
  }],{scales:scaleOpts});

  // Day of week
  if (d.dow_labels.length) mkChart('c-dow','bar',d.dow_labels,[{
    label:'Incidents', data:d.dow_data,
    backgroundColor:d.dow_labels.map((_,i)=>PALETTE[i%PALETTE.length]),
    borderRadius:7
  }],{plugins:{legend:{display:false}},scales:scaleOpts});

  // Group transfers
  if (d.xf_labels.length) mkChart('c-xfer','bar',d.xf_labels,[{
    label:'Incidents', data:d.xf_data,
    backgroundColor:'rgba(167,139,250,.75)', borderRadius:6
  }],{plugins:{legend:{display:false}},scales:scaleOpts});

  // SLA trend
  if (d.sla_tr_labels.length) mkChart('c-sla-trend','line',d.sla_tr_labels,[{
    label:'SLA Met %', data:d.sla_tr_vals,
    borderColor:'#30d988', backgroundColor:'rgba(48,217,136,.1)',
    fill:true, tension:.4, pointRadius:4, pointBackgroundColor:'#30d988'
  }],{scales:scaleOptsYpct});

  // SLA donut
  if (d.sla_labels.length) mkChart('c-sla-donut','doughnut',d.sla_labels,[{
    data:d.sla_data, backgroundColor:d.sla_labels.map(l=>SLA_MAP[l]||PALETTE[4]),
    borderWidth:2, borderColor:'#131720'
  }],{cutout:'64%'});

  // SLA by priority bar
  if (d.sla_pri_labels.length) mkChart('c-sla-pri','bar',d.sla_pri_labels,[{
    label:'SLA Met %', data:d.sla_pri_vals,
    backgroundColor:d.sla_pri_vals.map(v=>v>=70?'#30d988':v>=50?'#ffc240':'#ff4f6a'),
    borderRadius:8, borderSkipped:false
  }],{plugins:{legend:{display:false}},scales:scaleOptsYpct});

  // MTTR by group
  if (d.mttr_grp_labels.length) mkChart('c-mttr-grp','bar',d.mttr_grp_labels,[{
    label:'Avg Hours', data:d.mttr_grp_vals,
    backgroundColor:'rgba(255,194,64,.75)', borderRadius:7, borderSkipped:false
  }],{indexAxis:'y',plugins:{legend:{display:false}},
    scales:{x:{grid:{color:'#1f2738'},ticks:{callback:v=>v+'h'}},y:{grid:{display:false}}}});

  // CI bar
  if (d.ci_labels.length) mkChart('c-ci','bar',d.ci_labels,[{
    label:'Incidents', data:d.ci_data,
    backgroundColor:'rgba(34,211,238,.7)', borderRadius:6, borderSkipped:false
  }],{indexAxis:'y',plugins:{legend:{display:false}},scales:{x:{grid:{color:'#1f2738'}},y:{grid:{display:false}}}});

  // Service type
  if (d.svc_labels.length) mkChart('c-svc','doughnut',d.svc_labels,[{
    data:d.svc_data, backgroundColor:PALETTE, borderWidth:2, borderColor:'#131720'
  }],{cutout:'55%'});
}

// ── tables ────────────────────────────────────────────────────────────────────
function buildTables(d) {
  // Org table
  const orgTbody = document.getElementById('org-tbody');
  orgTbody.innerHTML = d.org_rows.map(r => {
    const sla = parseFloat(r.sla_pct) || 0;
    const cls = sla>=70?'c-met':sla>=50?'c-pend':'c-breach';
    return `<tr>
      <td style="font-weight:700">${r.Assigned_Support_Organisation||'—'}</td>
      <td style="font-family:'DM Mono',monospace;font-weight:700">${r.total}</td>
      <td><span class="chip c-breach">${r.open||0}</span></td>
      <td><span class="chip ${cls}">${sla}%</span></td>
      <td style="font-family:'DM Mono',monospace">${r.mttr||'—'}</td>
      <td><div class="mbar"><div class="mbar-bg"><div class="mbar-fill" style="width:${Math.min(sla,100)}%;background:${sla>=70?'#30d988':sla>=50?'#ffc240':'#ff4f6a'}"></div></div></div></td>
    </tr>`;
  }).join('');

  // Team table – dynamic headers
  const thead = document.getElementById('team-thead');
  const tbody = document.getElementById('team-tbody');
  if (d.assignee_rows.length) {
    const sample = d.assignee_rows[0];
    const keys = Object.keys(sample);
    thead.innerHTML = keys.map(k=>`<th>${k.replace(/_/g,' ')}</th>`).join('');
    const maxTotal = Math.max(...d.assignee_rows.map(r=>parseFloat(r.Total)||0));
    tbody.innerHTML = d.assignee_rows.map((r,i)=>{
      const sla = parseFloat(r.SLA_Pct)||0;
      const slaCls = sla>=70?'c-met':sla>=50?'c-pend':'c-breach';
      const pct = maxTotal>0 ? Math.round((parseFloat(r.Total)||0)/maxTotal*100) : 0;
      return '<tr>' + keys.map(k => {
        const v = r[k];
        if (k==='SLA_Pct') return `<td><span class="chip ${slaCls}">${v}%</span></td>`;
        if (k==='AssignedGroup') return `<td><span class="chip c-blue">${v}</span></td>`;
        if (k==='Assigned_Support_Organisation') return `<td><span style="font-size:.72rem;color:var(--muted)">${v}</span></td>`;
        if (k==='Total') return `<td><div class="mbar"><div class="mbar-bg"><div class="mbar-fill" style="width:${pct}%;background:var(--blue)"></div></div><span style="font-family:'DM Mono',monospace;font-size:.75rem;color:var(--muted)">${v}</span></div></td>`;
        return `<td style="font-family:'DM Mono',monospace;font-size:.78rem">${v}</td>`;
      }).join('') + '</tr>';
    }).join('');
  }

  // CI > 3 table
  document.getElementById('ci3-badge').textContent = d.ci_gt3_rows.length + ' CIs';
  const ci3Max = d.ci_gt3_rows.length ? Math.max(...d.ci_gt3_rows.map(r=>r.count)) : 1;
  document.getElementById('ci3-tbody').innerHTML = d.ci_gt3_rows.map((r,i) => {
    const pct = Math.round((r.count/ci3Max)*100);
    return `<tr>
      <td style="color:var(--dim);font-family:'DM Mono',monospace">${i+1}</td>
      <td style="font-weight:700;font-family:'DM Mono',monospace;color:var(--cyan)">${r.HPD_CI}</td>
      <td><span class="chip c-orange" style="font-family:'DM Mono',monospace;font-size:.82rem">${r.count}</span></td>
      <td><div class="mbar"><div class="mbar-bg"><div class="mbar-fill" style="width:${pct}%;background:var(--orange)"></div></div></div></td>
    </tr>`;
  }).join('');
}

// ── data info ─────────────────────────────────────────────────────────────────
function buildDataInfo(d) {
  document.getElementById('col-list').innerHTML =
    d.detected_cols.map(c=>`<span class="info-col">${c}</span>`).join('');
  document.getElementById('col-map-info').innerHTML =
    d.detected_cols.map(c=>`<div><span style="color:var(--blue)">${c}</span> → detected ✓</div>`).join('');
}
</script>
</body>
</html>
"""

# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n" + "="*55)
    print("  ITIS Incident Analyzer")
    print("="*55)
    print("  Open your browser and go to:")
    print("  http://localhost:5050")
    print("="*55)
    print("  Supports: .xlsx  .xls  .csv")
    print("  Columns are auto-detected.")
    print("  Press Ctrl+C to stop.\n")
    app.run(debug=False, port=5050, host="0.0.0.0")
