# ITIS Incident Analyzer — Python App

A self-contained web application that lets you upload any ITIS Excel/CSV export
and instantly generates an interactive 5-tab dashboard.

---

## 🚀 Quick Start

### Step 1 — Install dependencies (one-time only)
Open a terminal / command prompt in this folder and run:

```bash
pip install -r requirements.txt
```

### Step 2 — Run the app
```bash
python app.py
```

### Step 3 — Open browser
Go to: **http://localhost:5050**

Upload your `.xlsx`, `.xls`, or `.csv` file and click **Analyse File →**

---

## 📊 Dashboard Tabs

| Tab | Contents |
|-----|----------|
| 📊 Overview | 8 KPIs · Priority/Status charts · Group summary · Org table |
| 📈 Trends | Monthly volume · Day-of-week · SLA trend · Group Transfers |
| 🎯 SLA Analysis | SLAStatus breakdown · SLA % by Priority · MTTR by Group |
| 👥 Team Performance | Full Assignee/Group/Org performance table |
| 🖥 CI & Service | Top HPD_CI · Service_Type · CIs with >3 incidents |
| 🔍 Data Info | All detected columns · Date format explanation |

---

## 📋 Supported Columns

The app auto-detects these columns (also handles alternate spellings):

| Column | Type | Description |
|--------|------|-------------|
| Incident_Number | Text | INC ID |
| Summary | Text | Issue description |
| ReportedDate | **Number** | Excel serial → converted to datetime |
| LastResolvedDate | **Number** | Excel serial → converted to datetime |
| SubmitDate | **Number** | Excel serial → converted to datetime |
| Service_Type | Text | Incident type |
| HPD_CI | Text | Asset / server name |
| SLAStatus | Text | Met or Breached |
| Priority | Text | Critical / High / Medium / Low |
| AssignedGroup | Text | Resolving team |
| Assignee | Text | Person who resolved |
| Assigned_Support_Organisation | Text | Tower / Org name |
| Assigned_Support_Company | Text | Company name |
| Status | Text | Incident status |
| Group_Transfers | Number | Transfer count |

**Extra columns in your file are automatically included** in the Team table.

---

## ⏱ MTTR Calculation

Since your date columns are stored as Excel serial numbers:

```
MTTR (hours) = (LastResolvedDate − ReportedDate) × 24
Total Hours   = sum of all individual resolution times
```

The app handles the conversion automatically.

---

## 🔄 Using With New Data

Just click **← Upload New File** at the top of the dashboard to upload a fresh file.
No restart needed.

---

## 🛠 Requirements

- Python 3.8+
- See `requirements.txt`
